REPRESENTATIVE JAW FIT SAMPLE

Selected actual surface facets: jaw-T0061, jaw-T0062, jaw-T0063, jaw-T0064, jaw-T0065, jaw-T0066, jaw-T0067, jaw-T0068. They form four adjacent quads on the jaw around the v=0.25–0.333 region. This README carries every matching edge internal to the sample; no external manifest is needed for the paper-first test.

PAPER FIRST
1. Print representative-jaw-fit-manual-trim.svg at 100% / actual size on tiled paper. The SVG page is 304.8 × 508 mm.
2. Confirm the two registration crosshairs are 290.8 mm apart horizontally and that the page was not scaled.
3. Cut the paper triangles by hand and tape their matching edges to check curvature and assembly order.
4. Only after that succeeds, have trained Denhac staff run representative-jaw-fit-mark.svg on approved test stock using settings established by the separate coupon.
5. The two crosshairs are marking/registration strokes outside the facet art. Align the manual trim reference to those marks, then mechanically trim. No metal perimeter cutting path is included or authorized.

INTERNAL MATCHING EDGES
- jaw-T0061:E2 ↔ jaw-T0062:E3
- jaw-T0062:E2 ↔ jaw-T0063:E1
- jaw-T0063:E2 ↔ jaw-T0064:E3
- jaw-T0064:E2 ↔ jaw-T0065:E1
- jaw-T0065:E2 ↔ jaw-T0066:E3
- jaw-T0066:E2 ↔ jaw-T0067:E1
- jaw-T0067:E2 ↔ jaw-T0068:E3

Edges not listed above connect to facets outside this eight-facet sample and remain open during this local test. E1, E2, and E3 are printed beside each triangle edge on the manual-trim page.

The sample validates scale, registration, mark quality, manual trimming, and local fit only. It does not resolve the full sculpture crossing, global panel seams, overlap tabs, adhesive, or continuous blanket construction.

OPEN-SOURCE REUSE
The project-authored files may be used, changed, fabricated, exhibited, sold, and shared under your choice of MIT or Apache-2.0. Keep the notice and chosen license with redistributed files. Great Vibes remains under OFL-1.1. See REUSE.txt and the bundled license files.
